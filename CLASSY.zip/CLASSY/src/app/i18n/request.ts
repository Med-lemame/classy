import { notFound } from 'next/navigation';
import type { GetRequestConfigParams, RequestConfig } from 'next-intl/server';

export const locales = ['ar', 'en'] as const;
export type AppLocale = (typeof locales)[number];

export default async function getRequestConfig(
  { locale }: GetRequestConfigParams
): Promise<RequestConfig> {
  if (!locales.includes(locale as AppLocale)) notFound();
  const messages = (await import(`../messages/${locale}.json`)).default;
  return { locale: locale as AppLocale, messages };
}
