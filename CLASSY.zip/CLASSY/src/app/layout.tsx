import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "متجر كلاسي - Classy Store",
  description: "متجر إلكتروني متكامل للأزياء الرجالية الأنيقة",
};

// This is the root layout that wraps all pages
// The actual layout with navigation is in [locale]/layout.tsx
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html>
      <body>
        {children}
      </body>
    </html>
  );
}
