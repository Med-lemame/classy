import {notFound} from 'next/navigation';
import type {GetRequestConfigParams, RequestConfig} from 'next-intl/server';

export const locales = ['ar', 'en'] as const;
export type AppLocale = (typeof locales)[number];

export default async function getRequestConfig(
  {locale}: GetRequestConfigParams
): Promise<RequestConfig> {
  // لو اللغة غير مدعومة → 404
  if (!locales.includes(locale as AppLocale)) notFound();

  const safeLocale = locale as AppLocale;
  // حمّل رسائل الترجمة
  const messages = (await import(`../messages/${locale}.json`)).default;

  // ممكن تحدد اتجاه الصفحة هنا
  // const direction: 'rtl' | 'ltr' = locale === 'ar' ? 'rtl' : 'ltr';

  return {
    locale: safeLocale,
    messages
    // ممكن تضيف {timeZone, now} إن احتجت
  };
}
