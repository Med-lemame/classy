export default function HomePage() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">
          مرحباً بكم في متجر كلاسي
        </h1>
        <p className="text-xl text-gray-600">
          متجر إلكتروني متكامل للأزياء الرجالية الأنيقة
        </p>
      </div>
    </div>
  )
}