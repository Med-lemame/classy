import link from "next/link";
import Image from "next/image";
import { prisma } from '@/lib/prisma'
import { ProductCard } from '@/components/product/ProductCard'
import { HeroSection } from '@/components/home/HeroSection'
import { CategoryGrid } from '@/components/home/CategoryGrid'

// ✅ نوع موحّد يقبل الشكلين: compareAtPrice و comparePrice
type ProductLike = {
  id: string;
  name: string;
  image: string | null;
  price: number;
  createdAt: Date | string;
  updatedAt: Date | string;
  compareAtPrice?: number | null;
  // نسمح بالمسمّى القديم كي لا تكسر الكود الحالي
  comparePrice?: number | null;
};

// ✅ دالة صغيرة تُعيد السعر المقارن من أي اسم موجود
const getCompare = (p: { compareAtPrice?: number | null; comparePrice?: number | null }) =>
  (p.compareAtPrice ?? p.comparePrice ?? null);


export default async function HomePage() {
  try {
    // Fetch featured products
    const featuredProductsRaw = await prisma.product.findMany({
      where: {
        featured: true,
        published: true,
        status: 'ACTIVE'
      },
      include: {
        category: true,
        variants: true
      },
      take: 8
    })

    // Convert Decimal to number for client components
    const featuredProducts = featuredProductsRaw.map(product => ({
      ...product,
      price: Number(product.price),
      comparePrice: product.comparePrice ? Number(product.comparePrice) : null,
      variants: product.variants.map(variant => ({
        ...variant,
        price: Number(variant.price),
      
      }))
    }))

    // Fetch categories
    const categories = await prisma.category.findMany({
      where: {
        parentId: null // Only root categories
      },
      include: {
        _count: {
          select: {
            products: true
          }
        }
      },
      take: 5
    })

    return (
      <div className="min-h-screen">
        {/* Hero Section */}
        <HeroSection />

        {/* Featured Products */}
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">
                المنتجات المميزة
              </h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                اكتشف مجموعتنا المختارة من أفضل المنتجات عالية الجودة
              </p>
            </div>

            {featuredProducts.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {featuredProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">لا توجد منتجات مميزة حالياً</p>
              </div>
            )}
          </div>
        </section>

        {/* Categories */}
        <CategoryGrid categories={categories} />

        {/* Call to Action */}
        <section className="py-16 bg-blue-600 text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-4">
              ابدأ التسوق الآن
            </h2>
            <p className="text-xl mb-8 opacity-90">
              اكتشف مجموعتنا الكاملة من المنتجات عالية الجودة
            </p>
            <link
              href="/ar/shop"
              className="inline-block bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              تصفح المتجر
            </link>
          </div>
        </section>
      </div>
    )
  } catch (error) {
    console.error('Error loading homepage:', error)
    
    // Fallback UI in case of database error
    return (
      <div className="min-h-screen">
        <HeroSection />
        
        <section className="py-16 bg-gray-50">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              مرحباً بكم في متجر كلاسي
            </h2>
            <p className="text-gray-600 mb-8">
              نعتذر، هناك مشكلة مؤقتة في تحميل المنتجات. يرجى المحاولة لاحقاً.
            </p>
            <link
              href="/ar/shop"
              className="inline-block bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              تصفح المتجر
            </link>
          </div>
        </section>
      </div>
    )
  }
}